from django.db import models
import uuid


class Payment(models.Model):
    STATUS_CHOICES = [
        ('created', 'Created'),
        ('pending', 'Pending'),
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    ]
    GATEWAY_CHOICES = [('razorpay', 'Razorpay'), ('stripe', 'Stripe')]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking = models.OneToOneField('bookings.Booking', on_delete=models.CASCADE, related_name='payment')
    gateway = models.CharField(max_length=20, choices=GATEWAY_CHOICES, default='razorpay')
    gateway_order_id = models.CharField(max_length=200, blank=True)
    gateway_payment_id = models.CharField(max_length=200, blank=True)
    gateway_signature = models.CharField(max_length=500, blank=True)
    idempotency_key = models.CharField(max_length=100, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=5, default='INR')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='created')
    webhook_received = models.BooleanField(default=False)
    webhook_event_id = models.CharField(max_length=200, blank=True)  # Idempotency for webhooks
    failure_reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=['gateway_order_id']),
            models.Index(fields=['gateway_payment_id']),
            models.Index(fields=['idempotency_key']),
            models.Index(fields=['status']),
            models.Index(fields=['webhook_event_id']),
        ]

    def __str__(self):
        return f"Payment {self.id} - {self.status}"


class WebhookEvent(models.Model):
    """Stores raw webhook events to prevent duplicate processing."""
    event_id = models.CharField(max_length=200, unique=True)
    gateway = models.CharField(max_length=20)
    event_type = models.CharField(max_length=100)
    payload = models.JSONField()
    processed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=['event_id']), models.Index(fields=['processed'])]
