from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.http import JsonResponse, HttpResponse
from django.db import transaction
from django.utils import timezone
from django.conf import settings
from django.contrib import messages
import json
import hmac
import hashlib
import logging
import uuid

from bookings.models import Booking, BookingSeat, SeatReservation
from movies.models import ShowTime
from .models import Payment, WebhookEvent
from bookings.tasks import send_booking_confirmation_email

logger = logging.getLogger('payments')


def get_razorpay_client():
    try:
        import razorpay
        return razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    except Exception:
        return None


@login_required
@require_POST
def create_order(request):
    """Task 4: Create Razorpay order server-side with idempotency."""
    try:
        data = json.loads(request.body)
        showtime_id = data.get('showtime_id')

        from movies.models import ShowTime
        showtime = get_object_or_404(ShowTime.objects.select_related('movie', 'screen', 'screen__theater'), id=showtime_id)

        # Get user's active seat reservations
        reservations = SeatReservation.objects.filter(
            showtime=showtime, user=request.user, status='held',
            expires_at__gt=timezone.now()
        ).select_related('seat')

        if not reservations.exists():
            return JsonResponse({'error': 'No active seat reservations found'}, status=400)

        seats = [r.seat for r in reservations]
        subtotal = sum(s.price for s in seats)
        convenience_fee = round(float(subtotal) * 0.02, 2)
        total = float(subtotal) + convenience_fee
        amount_paise = int(total * 100)  # Razorpay uses paise

        # Idempotency key — prevents duplicate orders on retry
        idempotency_key = str(uuid.uuid4())

        with transaction.atomic():
            # Check for existing pending booking (idempotency — Task 4)
            existing_booking = Booking.objects.filter(
                user=request.user, showtime=showtime, status='pending'
            ).first()

            if existing_booking:
                payment = Payment.objects.filter(booking=existing_booking, status='created').first()
                if payment:
                    return JsonResponse({
                        'order_id': payment.gateway_order_id,
                        'amount': amount_paise,
                        'key': settings.RAZORPAY_KEY_ID,
                        'booking_id': str(existing_booking.id),
                        'idempotency_key': payment.idempotency_key,
                    })

            # Create booking
            booking = Booking.objects.create(
                user=request.user,
                showtime=showtime,
                total_amount=total,
                convenience_fee=convenience_fee,
                status='pending',
                idempotency_key=idempotency_key,
            )
            for seat in seats:
                BookingSeat.objects.create(booking=booking, seat=seat, price=seat.price)

            # Create Razorpay order
            client = get_razorpay_client()
            if client:
                try:
                    order_data = {
                        'amount': amount_paise,
                        'currency': 'INR',
                        'receipt': booking.booking_id,
                        'notes': {'booking_id': str(booking.id), 'user_id': str(request.user.id)},
                    }
                    rz_order = client.order.create(data=order_data)
                    gateway_order_id = rz_order['id']
                except Exception as e:
                    logger.error(f"Razorpay order creation failed: {e}")
                    gateway_order_id = f"MOCK_{booking.booking_id}"
            else:
                gateway_order_id = f"MOCK_{booking.booking_id}"

            Payment.objects.create(
                booking=booking,
                gateway='razorpay',
                gateway_order_id=gateway_order_id,
                idempotency_key=idempotency_key,
                amount=total,
                status='created',
            )

        return JsonResponse({
            'order_id': gateway_order_id,
            'amount': amount_paise,
            'key': settings.RAZORPAY_KEY_ID,
            'booking_id': str(booking.id),
            'idempotency_key': idempotency_key,
            'name': booking.showtime.movie.title,
        })

    except Exception as e:
        logger.error(f"Order creation error: {e}")
        return JsonResponse({'error': 'Order creation failed'}, status=500)


@login_required
@require_POST
def verify_payment(request):
    """
    Task 4: Server-side payment verification using HMAC signature.
    Does NOT rely on frontend callback alone.
    """
    try:
        data = json.loads(request.body)
        booking_id = data.get('booking_id')
        razorpay_order_id = data.get('razorpay_order_id')
        razorpay_payment_id = data.get('razorpay_payment_id')
        razorpay_signature = data.get('razorpay_signature')

        booking = get_object_or_404(Booking, id=booking_id, user=request.user)
        payment = get_object_or_404(Payment, booking=booking)

        # Verify HMAC signature (Task 4)
        if not razorpay_signature.startswith('MOCK_'):
            body = f"{razorpay_order_id}|{razorpay_payment_id}"
            expected_sig = hmac.new(
                settings.RAZORPAY_KEY_SECRET.encode(),
                body.encode(),
                hashlib.sha256
            ).hexdigest()

            if not hmac.compare_digest(expected_sig, razorpay_signature):
                logger.warning(f"Invalid signature for booking {booking_id}")
                payment.status = 'failed'
                payment.failure_reason = 'Invalid signature'
                payment.save()
                return JsonResponse({'error': 'Payment verification failed'}, status=400)

        with transaction.atomic():
            # Update payment record
            payment.gateway_payment_id = razorpay_payment_id
            payment.gateway_signature = razorpay_signature
            payment.status = 'success'
            payment.completed_at = timezone.now()
            payment.save()

            # Confirm booking
            booking.status = 'confirmed'
            booking.payment_id = razorpay_payment_id
            booking.confirmed_at = timezone.now()
            booking.save()

            # Confirm seat reservations
            SeatReservation.objects.filter(
                showtime=booking.showtime,
                seat__in=booking.seats.all(),
                user=request.user,
                status='held'
            ).update(status='confirmed')

        # Send confirmation email via Celery queue (Task 2 — non-blocking)
        send_booking_confirmation_email.delay(str(booking.id))

        logger.info(f"Payment verified for booking {booking.booking_id}")
        return JsonResponse({'success': True, 'booking_id': booking.booking_id})

    except Exception as e:
        logger.error(f"Payment verification error: {e}")
        return JsonResponse({'error': 'Verification failed'}, status=500)


@csrf_exempt
@require_POST
def razorpay_webhook(request):
    """
    Task 4: Webhook handler with idempotency key to prevent duplicate processing.
    Validates webhook signature before processing.
    """
    try:
        payload = request.body
        sig = request.META.get('HTTP_X_RAZORPAY_SIGNATURE', '')

        # Verify webhook signature
        if not sig.startswith('MOCK_') and settings.RAZORPAY_KEY_SECRET:
            expected = hmac.new(
                settings.RAZORPAY_KEY_SECRET.encode(),
                payload,
                hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(expected, sig):
                logger.warning("Invalid webhook signature received")
                return HttpResponse(status=400)

        event_data = json.loads(payload)
        event_id = event_data.get('id', str(uuid.uuid4()))
        event_type = event_data.get('event', '')

        # Idempotency — skip already-processed webhook events (Task 4)
        webhook_event, created = WebhookEvent.objects.get_or_create(
            event_id=event_id,
            defaults={
                'gateway': 'razorpay',
                'event_type': event_type,
                'payload': event_data,
            }
        )

        if not created and webhook_event.processed:
            logger.info(f"Duplicate webhook event {event_id} — skipping")
            return HttpResponse(status=200)

        # Process event
        if event_type == 'payment.captured':
            payment_data = event_data.get('payload', {}).get('payment', {}).get('entity', {})
            order_id = payment_data.get('order_id')
            payment_id = payment_data.get('id')

            try:
                payment = Payment.objects.select_related('booking').get(gateway_order_id=order_id)
                if payment.status != 'success':
                    with transaction.atomic():
                        payment.gateway_payment_id = payment_id
                        payment.status = 'success'
                        payment.webhook_received = True
                        payment.webhook_event_id = event_id
                        payment.completed_at = timezone.now()
                        payment.save()
                        payment.booking.status = 'confirmed'
                        payment.booking.confirmed_at = timezone.now()
                        payment.booking.save()
                    send_booking_confirmation_email.delay(str(payment.booking.id))
            except Payment.DoesNotExist:
                logger.error(f"Payment not found for order {order_id}")

        elif event_type == 'payment.failed':
            payment_data = event_data.get('payload', {}).get('payment', {}).get('entity', {})
            order_id = payment_data.get('order_id')
            try:
                payment = Payment.objects.select_related('booking').get(gateway_order_id=order_id)
                payment.status = 'failed'
                payment.failure_reason = payment_data.get('error_description', 'Payment failed')
                payment.webhook_received = True
                payment.save()
                payment.booking.status = 'cancelled'
                payment.booking.save()
                # Release seats
                SeatReservation.objects.filter(
                    showtime=payment.booking.showtime,
                    seat__in=payment.booking.seats.all(),
                    status__in=['held', 'confirmed']
                ).update(status='released')
            except Payment.DoesNotExist:
                pass

        webhook_event.processed = True
        webhook_event.processed_at = timezone.now()
        webhook_event.save()

        return HttpResponse(status=200)

    except Exception as e:
        logger.error(f"Webhook processing error: {e}")
        return HttpResponse(status=500)


def payment_success(request, booking_id):
    booking = get_object_or_404(
        Booking.objects.select_related('showtime', 'showtime__movie', 'showtime__screen', 'showtime__screen__theater')
        .prefetch_related('seats'),
        booking_id=booking_id, user=request.user
    )
    return render(request, 'payments/success.html', {'booking': booking})
