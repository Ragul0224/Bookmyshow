from django.contrib import admin
from .models import Payment, WebhookEvent


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ['id', 'booking', 'gateway', 'amount', 'status', 'created_at']
    list_filter = ['gateway', 'status']
    search_fields = ['gateway_order_id', 'gateway_payment_id', 'booking__booking_id']
    readonly_fields = ['id', 'created_at', 'updated_at', 'completed_at', 'idempotency_key']


@admin.register(WebhookEvent)
class WebhookEventAdmin(admin.ModelAdmin):
    list_display = ['event_id', 'gateway', 'event_type', 'processed', 'created_at']
    list_filter = ['gateway', 'processed', 'event_type']
    readonly_fields = ['created_at', 'processed_at']
