from django.urls import path
from . import views

app_name = 'analytics'

urlpatterns = [
    path('dashboard/', views.admin_dashboard, name='dashboard'),
    path('api/', views.analytics_api, name='api'),
]
