from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum, Count, Avg, F, Q, ExpressionWrapper, DecimalField
from django.db.models.functions import TruncDay, TruncWeek, TruncMonth, ExtractHour
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View
from django.http import JsonResponse
from django.core.cache import cache
from datetime import timedelta
from functools import wraps
import logging

logger = logging.getLogger('analytics')


def admin_required(view_func):
    """Task 6: Role-based access — only admin users can access analytics."""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('accounts:login')
        if not (request.user.is_superuser or getattr(request.user, 'role', '') == 'admin'):
            return redirect('movies:home')
        return view_func(request, *args, **kwargs)
    return wrapper


def cached_query(cache_key, timeout=300):
    """Decorator for caching expensive analytics queries (Task 6)."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            cached = cache.get(cache_key)
            if cached is not None:
                return cached
            result = func(*args, **kwargs)
            cache.set(cache_key, result, timeout)
            return result
        return wrapper
    return decorator


@admin_required
def admin_dashboard(request):
    """Task 6: Main analytics dashboard with role-based access."""
    from bookings.models import Booking

    period = request.GET.get('period', 'daily')
    now = timezone.now()

    # --- Revenue (Task 6: DB aggregation, not in-memory) ---
    cache_key = f'analytics_revenue_{period}'
    revenue_data = cache.get(cache_key)
    if not revenue_data:
        if period == 'daily':
            start = now - timedelta(days=30)
            revenue_qs = (
                Booking.objects.filter(status='confirmed', created_at__gte=start)
                .annotate(day=TruncDay('created_at'))
                .values('day')
                .annotate(revenue=Sum('total_amount'), bookings=Count('id'))
                .order_by('day')
            )
        elif period == 'weekly':
            start = now - timedelta(weeks=12)
            revenue_qs = (
                Booking.objects.filter(status='confirmed', created_at__gte=start)
                .annotate(week=TruncWeek('created_at'))
                .values('week')
                .annotate(revenue=Sum('total_amount'), bookings=Count('id'))
                .order_by('week')
            )
        else:  # monthly
            start = now - timedelta(days=365)
            revenue_qs = (
                Booking.objects.filter(status='confirmed', created_at__gte=start)
                .annotate(month=TruncMonth('created_at'))
                .values('month')
                .annotate(revenue=Sum('total_amount'), bookings=Count('id'))
                .order_by('month')
            )
        revenue_data = list(revenue_qs)
        cache.set(cache_key, revenue_data, 300)

    # --- Total stats ---
    today = now.date()
    total_revenue_today = Booking.objects.filter(
        status='confirmed', created_at__date=today
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    total_revenue_month = Booking.objects.filter(
        status='confirmed',
        created_at__year=now.year,
        created_at__month=now.month
    ).aggregate(total=Sum('total_amount'))['total'] or 0

    total_bookings = Booking.objects.filter(status='confirmed').count()
    cancellation_count = Booking.objects.filter(status='cancelled').count()
    cancellation_rate = (
        round(cancellation_count / (total_bookings + cancellation_count) * 100, 1)
        if (total_bookings + cancellation_count) > 0 else 0
    )

    # --- Most popular movies (Task 6) ---
    popular_movies_key = 'analytics_popular_movies'
    popular_movies = cache.get(popular_movies_key)
    if not popular_movies:
        from movies.models import Movie
        popular_movies = list(
            Movie.objects.annotate(
                booking_count=Count('showtimes__bookings', filter=Q(showtimes__bookings__status='confirmed')),
                total_revenue=Sum('showtimes__bookings__total_amount',
                                  filter=Q(showtimes__bookings__status='confirmed'))
            ).filter(booking_count__gt=0)
            .values('title', 'booking_count', 'total_revenue')
            .order_by('-booking_count')[:10]
        )
        cache.set(popular_movies_key, popular_movies, 300)

    # --- Busiest theaters by seat occupancy (Task 6) ---
    busy_theaters_key = 'analytics_busy_theaters'
    busy_theaters = cache.get(busy_theaters_key)
    if not busy_theaters:
        from movies.models import Theater
        busy_theaters = list(
            Theater.objects.annotate(
                total_bookings=Count('screens__showtimes__bookings',
                                     filter=Q(screens__showtimes__bookings__status='confirmed')),
                occupancy_revenue=Sum('screens__showtimes__bookings__total_amount',
                                      filter=Q(screens__showtimes__bookings__status='confirmed'))
            ).filter(total_bookings__gt=0)
            .values('name', 'city', 'total_bookings', 'occupancy_revenue')
            .order_by('-total_bookings')[:10]
        )
        cache.set(busy_theaters_key, busy_theaters, 300)

    # --- Peak booking hours (Task 6) ---
    peak_hours_key = 'analytics_peak_hours'
    peak_hours = cache.get(peak_hours_key)
    if not peak_hours:
        peak_hours = list(
            Booking.objects.filter(status='confirmed')
            .annotate(hour=ExtractHour('created_at'))
            .values('hour')
            .annotate(count=Count('id'))
            .order_by('hour')
        )
        cache.set(peak_hours_key, peak_hours, 600)

    context = {
        'revenue_data': revenue_data,
        'period': period,
        'total_revenue_today': total_revenue_today,
        'total_revenue_month': total_revenue_month,
        'total_bookings': total_bookings,
        'cancellation_rate': cancellation_rate,
        'popular_movies': popular_movies,
        'busy_theaters': busy_theaters,
        'peak_hours': peak_hours,
    }
    return render(request, 'admin_dashboard/dashboard.html', context)


@admin_required
def analytics_api(request):
    """Task 6: JSON API for real-time chart data."""
    from bookings.models import Booking

    metric = request.GET.get('metric', 'revenue')
    now = timezone.now()

    if metric == 'revenue':
        start = now - timedelta(days=30)
        data = list(
            Booking.objects.filter(status='confirmed', created_at__gte=start)
            .annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(value=Sum('total_amount'))
            .order_by('day')
        )
        return JsonResponse({'data': [{'x': str(d['day'].date()), 'y': float(d['value'] or 0)} for d in data]})

    elif metric == 'peak_hours':
        peak = list(
            Booking.objects.filter(status='confirmed')
            .annotate(hour=ExtractHour('created_at'))
            .values('hour')
            .annotate(count=Count('id'))
            .order_by('hour')
        )
        return JsonResponse({'data': [{'hour': d['hour'], 'bookings': d['count']} for d in peak]})

    return JsonResponse({'error': 'Unknown metric'}, status=400)
