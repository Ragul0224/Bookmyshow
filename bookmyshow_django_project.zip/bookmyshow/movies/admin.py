from django.contrib import admin
from .models import Movie, Genre, Language, Theater, Screen, Seat, ShowTime


@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Language)
class LanguageAdmin(admin.ModelAdmin):
    list_display = ['name', 'code']


@admin.register(Theater)
class TheaterAdmin(admin.ModelAdmin):
    list_display = ['name', 'city', 'state', 'total_screens']
    list_filter = ['city', 'state']
    search_fields = ['name', 'city']


class ScreenInline(admin.TabularInline):
    model = Screen
    extra = 1


@admin.register(Screen)
class ScreenAdmin(admin.ModelAdmin):
    list_display = ['name', 'theater', 'screen_type', 'total_seats']
    list_filter = ['screen_type', 'theater']


@admin.register(Seat)
class SeatAdmin(admin.ModelAdmin):
    list_display = ['screen', 'row', 'number', 'category', 'price']
    list_filter = ['screen', 'category']


@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ['title', 'release_date', 'rating', 'is_active', 'is_featured']
    list_filter = ['is_active', 'is_featured', 'rating', 'genres']
    search_fields = ['title']
    prepopulated_fields = {'slug': ('title',)}
    filter_horizontal = ['genres', 'languages']


@admin.register(ShowTime)
class ShowTimeAdmin(admin.ModelAdmin):
    list_display = ['movie', 'screen', 'language', 'show_date', 'show_time', 'available_seats']
    list_filter = ['show_date', 'language', 'screen__theater']
    search_fields = ['movie__title']
    date_hierarchy = 'show_date'
