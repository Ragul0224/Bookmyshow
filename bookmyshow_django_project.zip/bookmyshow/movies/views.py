from django.shortcuts import render, get_object_or_404
from django.db.models import Count, Q, Prefetch
from django.core.paginator import Paginator
from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator
from django.views import View
from django.http import JsonResponse
from django.utils import timezone
from .models import Movie, Genre, Language, ShowTime, Theater
import json


class MovieListView(View):
    """
    Task 1: Advanced genre & language filtering with:
    - Server-side multi-select filtering
    - Optimized queries with select_related / prefetch_related
    - DB-level aggregation for filter counts
    - No full-table scans (uses indexes on genre, language M2M tables)
    - Pagination that works with any filter combination
    """

    def get(self, request):
        # --- Build base queryset using indexed columns only ---
        qs = Movie.objects.filter(is_active=True).select_related().prefetch_related(
            Prefetch('genres', queryset=Genre.objects.only('id', 'name', 'slug')),
            Prefetch('languages', queryset=Language.objects.only('id', 'name', 'code')),
        )

        # --- Multi-select genre filter (Task 1) ---
        genre_slugs = request.GET.getlist('genre')  # e.g. ?genre=action&genre=comedy
        if genre_slugs:
            # Use __in + distinct to avoid cross-join duplication
            qs = qs.filter(genres__slug__in=genre_slugs).distinct()

        # --- Multi-select language filter (Task 1) ---
        lang_codes = request.GET.getlist('language')
        if lang_codes:
            qs = qs.filter(languages__code__in=lang_codes).distinct()

        # --- Rating filter ---
        rating = request.GET.get('rating')
        if rating:
            qs = qs.filter(rating=rating)

        # --- Sorting ---
        sort_by = request.GET.get('sort', '-release_date')
        VALID_SORTS = {
            'release_date': 'release_date', '-release_date': '-release_date',
            'title': 'title', '-title': '-title',
            'rating': '-average_rating',
        }
        qs = qs.order_by(VALID_SORTS.get(sort_by, '-release_date'))

        # --- Pagination ---
        paginator = Paginator(qs, 12)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)

        # --- Dynamic filter counts (Task 1) ---
        # Count movies per genre AFTER applying language filter (not genre filter)
        base_for_genre_count = Movie.objects.filter(is_active=True)
        if lang_codes:
            base_for_genre_count = base_for_genre_count.filter(languages__code__in=lang_codes).distinct()
        if rating:
            base_for_genre_count = base_for_genre_count.filter(rating=rating)

        genre_counts = (
            Genre.objects.filter(movies__in=base_for_genre_count)
            .annotate(movie_count=Count('movies', distinct=True))
            .values('slug', 'name', 'movie_count')
            .order_by('name')
        )

        # Count movies per language AFTER applying genre filter
        base_for_lang_count = Movie.objects.filter(is_active=True)
        if genre_slugs:
            base_for_lang_count = base_for_lang_count.filter(genres__slug__in=genre_slugs).distinct()
        if rating:
            base_for_lang_count = base_for_lang_count.filter(rating=rating)

        lang_counts = (
            Language.objects.filter(movies__in=base_for_lang_count)
            .annotate(movie_count=Count('movies', distinct=True))
            .values('code', 'name', 'movie_count')
            .order_by('name')
        )

        all_genres = list(genre_counts)
        all_languages = list(lang_counts)

        context = {
            'page_obj': page_obj,
            'all_genres': all_genres,
            'all_languages': all_languages,
            'selected_genres': genre_slugs,
            'selected_languages': lang_codes,
            'selected_rating': rating,
            'sort_by': sort_by,
            'total_count': qs.count(),
        }
        return render(request, 'movies/movie_list.html', context)


class MovieDetailView(View):
    """Task 3: Movie detail with secure YouTube embedding."""

    def get(self, request, slug):
        movie = get_object_or_404(
            Movie.objects.prefetch_related('genres', 'languages'),
            slug=slug, is_active=True
        )
        today = timezone.now().date()
        showtimes = (
            ShowTime.objects.filter(movie=movie, show_date__gte=today, is_active=True)
            .select_related('screen', 'screen__theater', 'language')
            .order_by('show_date', 'show_time')
        )
        # Group showtimes by theater
        theaters = {}
        for st in showtimes:
            t = st.screen.theater
            if t.id not in theaters:
                theaters[t.id] = {'theater': t, 'showtimes': []}
            theaters[t.id]['showtimes'].append(st)

        context = {
            'movie': movie,
            'embed_url': movie.get_safe_embed_url(),  # Task 3: safe embed
            'theaters': list(theaters.values()),
        }
        return render(request, 'movies/movie_detail.html', context)


class HomeView(View):
    def get(self, request):
        featured = Movie.objects.filter(is_active=True, is_featured=True).prefetch_related('genres', 'languages')[:6]
        now_showing = Movie.objects.filter(
            is_active=True, release_date__lte=timezone.now().date()
        ).prefetch_related('genres', 'languages').order_by('-release_date')[:8]
        coming_soon = Movie.objects.filter(
            is_active=True, release_date__gt=timezone.now().date()
        ).prefetch_related('genres', 'languages').order_by('release_date')[:6]
        context = {
            'featured': featured,
            'now_showing': now_showing,
            'coming_soon': coming_soon,
        }
        return render(request, 'movies/home.html', context)


def movie_filter_counts_api(request):
    """
    Task 1: API endpoint returning live filter counts for AJAX updates.
    Prevents full-table scans by using database aggregation.
    """
    genre_slugs = request.GET.getlist('genre')
    lang_codes = request.GET.getlist('language')

    base = Movie.objects.filter(is_active=True)
    if genre_slugs:
        base = base.filter(genres__slug__in=genre_slugs).distinct()
    if lang_codes:
        base = base.filter(languages__code__in=lang_codes).distinct()

    genre_counts = list(
        Genre.objects.filter(movies__in=base)
        .annotate(count=Count('movies', distinct=True))
        .values('slug', 'name', 'count')
    )
    lang_counts = list(
        Language.objects.filter(movies__in=base)
        .annotate(count=Count('movies', distinct=True))
        .values('code', 'name', 'count')
    )

    return JsonResponse({'genres': genre_counts, 'languages': lang_counts, 'total': base.count()})
