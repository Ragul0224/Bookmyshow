from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from decimal import Decimal
import random
from datetime import timedelta

User = get_user_model()


class Command(BaseCommand):
    help = 'Seed the database with demo data for BookMyShow'

    def handle(self, *args, **kwargs):
        self.stdout.write('🌱 Seeding database...')

        from movies.models import Genre, Language, Theater, Screen, Seat, Movie, ShowTime

        # --- Genres ---
        genres_data = [
            ('Action', 'action'), ('Comedy', 'comedy'), ('Drama', 'drama'),
            ('Horror', 'horror'), ('Romance', 'romance'), ('Thriller', 'thriller'),
            ('Sci-Fi', 'sci-fi'), ('Animation', 'animation'), ('Fantasy', 'fantasy'),
        ]
        genres = {}
        for name, slug in genres_data:
            g, _ = Genre.objects.get_or_create(name=name, defaults={'slug': slug})
            genres[slug] = g
        self.stdout.write('  ✓ Genres')

        # --- Languages ---
        langs_data = [
            ('Tamil', 'ta'), ('Hindi', 'hi'), ('English', 'en'),
            ('Telugu', 'te'), ('Malayalam', 'ml'), ('Kannada', 'kn'),
        ]
        langs = {}
        for name, code in langs_data:
            l, _ = Language.objects.get_or_create(name=name, defaults={'code': code})
            langs[code] = l
        self.stdout.write('  ✓ Languages')

        # --- Admin user ---
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin',
                email='admin@bookmyshow.com',
                password='Admin@1234',
                role='admin'
            )
            self.stdout.write('  ✓ Admin user (admin / Admin@1234)')

        # --- Test user ---
        if not User.objects.filter(username='testuser').exists():
            User.objects.create_user(
                username='testuser',
                email='test@example.com',
                password='Test@1234',
                phone='9876543210'
            )
            self.stdout.write('  ✓ Test user (testuser / Test@1234)')

        # --- Theaters ---
        theater_data = [
            ('PVR Cinemas', 'Anna Salai, Thousand Lights', 'Chennai', 'Tamil Nadu', '600002', 4),
            ('INOX Movies', 'Phoenix MarketCity, Velachery', 'Chennai', 'Tamil Nadu', '600042', 3),
            ('SPI Sathyam', 'Venkatnarayana Road, T. Nagar', 'Chennai', 'Tamil Nadu', '600017', 5),
            ('Cinepolis', 'GM Mall, Coimbatore', 'Coimbatore', 'Tamil Nadu', '641001', 3),
        ]
        theaters = []
        for name, addr, city, state, pin, screens in theater_data:
            t, _ = Theater.objects.get_or_create(
                name=name, city=city,
                defaults={'address': addr, 'state': state, 'pincode': pin, 'total_screens': screens}
            )
            theaters.append(t)
        self.stdout.write('  ✓ Theaters')

        # --- Screens and seats ---
        screen_types = ['2D', '3D', 'IMAX', '4DX']
        all_screens = []
        for theater in theaters:
            for i in range(1, 3):
                sc, created = Screen.objects.get_or_create(
                    theater=theater,
                    name=f'Screen {i}',
                    defaults={
                        'total_seats': 120,
                        'screen_type': screen_types[i % len(screen_types)]
                    }
                )
                all_screens.append(sc)
                if created:
                    # Create seats: Silver A-E (50), Gold F-I (40), Platinum J-K (30)
                    seat_configs = [
                        ('A', 'B', 'C', 'D', 'E'), 'silver', Decimal('150'),
                        ('F', 'G', 'H', 'I'), 'gold', Decimal('250'),
                        ('J', 'K'), 'platinum', Decimal('400'),
                    ]
                    seats = []
                    for rows, category, price in [
                        (list('ABCDE'), 'silver', Decimal('150')),
                        (list('FGHI'), 'gold', Decimal('250')),
                        (list('JK'), 'platinum', Decimal('400')),
                    ]:
                        for row in rows:
                            for num in range(1, 13):
                                seats.append(Seat(
                                    screen=sc, row=row, number=num,
                                    category=category, price=price
                                ))
                    Seat.objects.bulk_create(seats, ignore_conflicts=True)
        self.stdout.write('  ✓ Screens & Seats')

        # --- Movies ---
        movies_data = [
            {
                'title': 'Leo', 'duration_minutes': 164, 'rating': 'UA',
                'description': 'A mild-mannered man who runs a pet shop in Munnar has a dark past. When he is targeted by a gangster, his true identity begins to surface.',
                'genres': ['action', 'thriller'], 'languages': ['ta', 'hi', 'te'],
                'is_featured': True, 'release_date': timezone.now().date() - timedelta(days=30),
                'trailer_url': 'https://www.youtube.com/watch?v=Sax1gS3ISKI',
            },
            {
                'title': 'Jawan', 'duration_minutes': 169, 'rating': 'UA',
                'description': 'A man is driven by a personal vendetta to rectify the wrongs in society, while also fighting his mysterious past.',
                'genres': ['action', 'drama'], 'languages': ['hi', 'ta', 'te'],
                'is_featured': True, 'release_date': timezone.now().date() - timedelta(days=60),
                'trailer_url': 'https://www.youtube.com/watch?v=VTNEJk0V2aU',
            },
            {
                'title': 'Oppenheimer', 'duration_minutes': 180, 'rating': 'UA',
                'description': 'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.',
                'genres': ['drama', 'sci-fi'], 'languages': ['en'],
                'is_featured': False, 'release_date': timezone.now().date() - timedelta(days=90),
                'trailer_url': 'https://www.youtube.com/watch?v=uYPbbksJxIg',
            },
            {
                'title': 'Ponniyin Selvan 2', 'duration_minutes': 161, 'rating': 'UA',
                'description': 'The second part of the epic historical drama based on Kalki Krishnamurthy\'s novel.',
                'genres': ['action', 'drama', 'fantasy'], 'languages': ['ta', 'te', 'hi'],
                'is_featured': True, 'release_date': timezone.now().date() - timedelta(days=15),
                'trailer_url': 'https://www.youtube.com/watch?v=VLLQxQc_n5c',
            },
            {
                'title': 'Jailer', 'duration_minutes': 168, 'rating': 'UA',
                'description': 'A retired jailer takes on a drug lord to save his son. An action packed entertainer.',
                'genres': ['action', 'comedy'], 'languages': ['ta', 'hi', 'ml'],
                'is_featured': True, 'release_date': timezone.now().date() - timedelta(days=45),
                'trailer_url': 'https://www.youtube.com/watch?v=XMooCimBxWA',
            },
            {
                'title': 'Barbie', 'duration_minutes': 114, 'rating': 'UA',
                'description': 'Barbie and Ken are having the time of their lives in the colorful and seemingly perfect world of Barbie Land.',
                'genres': ['comedy', 'fantasy', 'romance'], 'languages': ['en'],
                'is_featured': False, 'release_date': timezone.now().date() - timedelta(days=120),
                'trailer_url': 'https://www.youtube.com/watch?v=pBk4NYhWNMM',
            },
            {
                'title': 'Kalki 2898 AD', 'duration_minutes': 181, 'rating': 'UA',
                'description': 'A futuristic mythological epic set in 2898 AD.',
                'genres': ['sci-fi', 'action', 'fantasy'], 'languages': ['te', 'ta', 'hi', 'ml'],
                'is_featured': True, 'release_date': timezone.now().date() + timedelta(days=20),
                'trailer_url': '',
            },
            {
                'title': 'The Kerala Story', 'duration_minutes': 138, 'rating': 'A',
                'description': 'A dramatic story based on real events in Kerala.',
                'genres': ['drama', 'thriller'], 'languages': ['hi', 'ml'],
                'is_featured': False, 'release_date': timezone.now().date() - timedelta(days=200),
                'trailer_url': '',
            },
        ]

        movies = []
        from django.utils.text import slugify
        for md in movies_data:
            slug = slugify(md['title'])
            m, created = Movie.objects.get_or_create(
                slug=slug,
                defaults={
                    'title': md['title'],
                    'description': md['description'],
                    'duration_minutes': md['duration_minutes'],
                    'rating': md['rating'],
                    'release_date': md['release_date'],
                    'is_featured': md['is_featured'],
                    'is_active': True,
                    'trailer_url': md.get('trailer_url', ''),
                }
            )
            if created:
                m.genres.set([genres[g] for g in md['genres'] if g in genres])
                m.languages.set([langs[l] for l in md['languages'] if l in langs])
                m.save()
            movies.append(m)
        self.stdout.write('  ✓ Movies')

        # --- Showtimes ---
        today = timezone.now().date()
        times = ['10:00', '13:30', '17:00', '20:30']
        showtime_count = 0
        for movie in movies:
            if movie.release_date > today:
                continue
            for day_offset in range(7):
                show_date = today + timedelta(days=day_offset)
                for screen in all_screens[:4]:
                    lang = random.choice(list(movie.languages.all()))
                    time_str = random.choice(times)
                    from datetime import time
                    h, m2 = map(int, time_str.split(':'))
                    show_time = time(h, m2)
                    st, created = ShowTime.objects.get_or_create(
                        screen=screen,
                        show_date=show_date,
                        show_time=show_time,
                        defaults={
                            'movie': movie,
                            'language': lang,
                            'base_price': Decimal('150'),
                            'available_seats': screen.total_seats,
                            'is_active': True,
                        }
                    )
                    if created:
                        showtime_count += 1
        self.stdout.write(f'  ✓ {showtime_count} Showtimes')

        self.stdout.write(self.style.SUCCESS('\n✅ Database seeded successfully!'))
        self.stdout.write('\n👤 Login credentials:')
        self.stdout.write('   Admin  → username: admin    | password: Admin@1234')
        self.stdout.write('   User   → username: testuser | password: Test@1234')
        self.stdout.write('\n📊 Admin Dashboard: /analytics/dashboard/')
        self.stdout.write('🔧 Django Admin:    /admin/')
