from django.urls import path
from . import views

app_name = 'movies'

urlpatterns = [
    path('', views.HomeView.as_view(), name='home'),
    path('movies/', views.MovieListView.as_view(), name='movie_list'),
    path('movies/<slug:slug>/', views.MovieDetailView.as_view(), name='movie_detail'),
    path('api/filter-counts/', views.movie_filter_counts_api, name='filter_counts_api'),
]
