from django.db import models
from django.utils.text import slugify
import bleach
import re


GENRE_CHOICES = [
    ('action', 'Action'), ('comedy', 'Comedy'), ('drama', 'Drama'),
    ('horror', 'Horror'), ('romance', 'Romance'), ('thriller', 'Thriller'),
    ('sci-fi', 'Sci-Fi'), ('animation', 'Animation'), ('documentary', 'Documentary'),
    ('fantasy', 'Fantasy'), ('mystery', 'Mystery'), ('biography', 'Biography'),
]

LANGUAGE_CHOICES = [
    ('tamil', 'Tamil'), ('hindi', 'Hindi'), ('english', 'English'),
    ('telugu', 'Telugu'), ('malayalam', 'Malayalam'), ('kannada', 'Kannada'),
    ('bengali', 'Bengali'), ('marathi', 'Marathi'),
]

RATING_CHOICES = [('U', 'U'), ('UA', 'U/A'), ('A', 'A'), ('S', 'S')]


class Genre(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(unique=True)

    class Meta:
        indexes = [models.Index(fields=['slug'])]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Language(models.Model):
    name = models.CharField(max_length=50, unique=True)
    code = models.CharField(max_length=10, unique=True)

    class Meta:
        indexes = [models.Index(fields=['code'])]

    def __str__(self):
        return self.name


class Theater(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    total_screens = models.PositiveIntegerField(default=1)
    amenities = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=['city']), models.Index(fields=['state'])]

    def __str__(self):
        return f"{self.name} - {self.city}"


class Screen(models.Model):
    theater = models.ForeignKey(Theater, on_delete=models.CASCADE, related_name='screens')
    name = models.CharField(max_length=50)
    total_seats = models.PositiveIntegerField(default=100)
    screen_type = models.CharField(max_length=20, choices=[('2D', '2D'), ('3D', '3D'), ('IMAX', 'IMAX'), ('4DX', '4DX')], default='2D')

    def __str__(self):
        return f"{self.theater.name} - {self.name}"


class Seat(models.Model):
    CATEGORY_CHOICES = [('silver', 'Silver'), ('gold', 'Gold'), ('platinum', 'Platinum')]
    screen = models.ForeignKey(Screen, on_delete=models.CASCADE, related_name='seats')
    row = models.CharField(max_length=5)
    number = models.PositiveIntegerField()
    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES, default='silver')
    price = models.DecimalField(max_digits=8, decimal_places=2)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ['screen', 'row', 'number']
        indexes = [
            models.Index(fields=['screen', 'category']),
            models.Index(fields=['screen', 'row']),
        ]

    def __str__(self):
        return f"{self.row}{self.number} ({self.category})"


def validate_youtube_url(url):
    """Validate that URL is a proper YouTube URL to prevent XSS."""
    pattern = r'^https?://(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[A-Za-z0-9_-]{11}(&.*)?$'
    return bool(re.match(pattern, url)) if url else False


class Movie(models.Model):
    title = models.CharField(max_length=300)
    slug = models.SlugField(unique=True, max_length=350)
    description = models.TextField()
    release_date = models.DateField()
    duration_minutes = models.PositiveIntegerField()
    rating = models.CharField(max_length=5, choices=RATING_CHOICES, default='UA')
    genres = models.ManyToManyField(Genre, related_name='movies')
    languages = models.ManyToManyField(Language, related_name='movies')
    poster = models.ImageField(upload_to='posters/', blank=True, null=True)
    banner = models.ImageField(upload_to='banners/', blank=True, null=True)
    trailer_url = models.URLField(blank=True, max_length=300)
    trailer_embed_id = models.CharField(max_length=20, blank=True)
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    average_rating = models.DecimalField(max_digits=3, decimal_places=1, default=0.0)
    total_reviews = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['slug']),
            models.Index(fields=['is_active', 'release_date']),
            models.Index(fields=['is_featured', 'is_active']),
            models.Index(fields=['rating']),
        ]
        ordering = ['-release_date']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        # Sanitize description
        self.description = bleach.clean(self.description, tags=['p', 'br', 'strong', 'em'], strip=True)
        # Extract YouTube video ID for safe embedding
        if self.trailer_url:
            if validate_youtube_url(self.trailer_url):
                match = re.search(r'(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})', self.trailer_url)
                if match:
                    self.trailer_embed_id = match.group(1)
            else:
                self.trailer_url = ''
                self.trailer_embed_id = ''
        super().save(*args, **kwargs)

    def get_safe_embed_url(self):
        """Returns a safe embed URL with security params."""
        if self.trailer_embed_id:
            return f"https://www.youtube-nocookie.com/embed/{self.trailer_embed_id}?rel=0&modestbranding=1"
        return None

    def __str__(self):
        return self.title


class ShowTime(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='showtimes')
    screen = models.ForeignKey(Screen, on_delete=models.CASCADE, related_name='showtimes')
    language = models.ForeignKey(Language, on_delete=models.SET_NULL, null=True)
    show_date = models.DateField()
    show_time = models.TimeField()
    base_price = models.DecimalField(max_digits=8, decimal_places=2)
    available_seats = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ['screen', 'show_date', 'show_time']
        indexes = [
            models.Index(fields=['movie', 'show_date']),
            models.Index(fields=['screen', 'show_date']),
            models.Index(fields=['show_date', 'is_active']),
            models.Index(fields=['language', 'show_date']),
        ]

    def __str__(self):
        return f"{self.movie.title} - {self.show_date} {self.show_time}"
