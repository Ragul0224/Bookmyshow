from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.db import transaction
from django.db.models import F
from django.utils import timezone
from django.http import JsonResponse
from django.conf import settings
from django.contrib import messages
import json
import logging

from movies.models import ShowTime, Seat
from .models import SeatReservation, Booking, BookingSeat
from .tasks import send_booking_confirmation_email

logger = logging.getLogger('bookings')


@login_required
def seat_selection(request, showtime_id):
    showtime = get_object_or_404(
        ShowTime.objects.select_related('movie', 'screen', 'screen__theater', 'language'),
        id=showtime_id, is_active=True
    )
    seats = Seat.objects.filter(screen=showtime.screen, is_active=True).order_by('row', 'number')

    # Get currently reserved/confirmed seat IDs
    held_seat_ids = set(
        SeatReservation.objects.filter(
            showtime=showtime,
            status='held',
            expires_at__gt=timezone.now()
        ).values_list('seat_id', flat=True)
    )
    confirmed_seat_ids = set(
        SeatReservation.objects.filter(
            showtime=showtime,
            status='confirmed'
        ).values_list('seat_id', flat=True)
    )
    booked_seat_ids = held_seat_ids | confirmed_seat_ids

    # Get user's own held seats
    user_held = set(
        SeatReservation.objects.filter(
            showtime=showtime, user=request.user, status='held',
            expires_at__gt=timezone.now()
        ).values_list('seat_id', flat=True)
    )

    # Group seats by row
    rows = {}
    for seat in seats:
        if seat.row not in rows:
            rows[seat.row] = []
        rows[seat.row].append({
            'id': seat.id,
            'number': seat.number,
            'category': seat.category,
            'price': float(seat.price),
            'is_booked': seat.id in booked_seat_ids,
            'is_mine': seat.id in user_held,
        })

    timeout = getattr(settings, 'SEAT_RESERVATION_TIMEOUT', 120)
    context = {
        'showtime': showtime,
        'rows': dict(sorted(rows.items())),
        'timeout': timeout,
    }
    return render(request, 'bookings/seat_selection.html', context)


@login_required
@require_POST
def reserve_seats(request):
    """
    Task 5: Atomic seat reservation with row-level locking.
    Prevents race conditions using select_for_update().
    """
    try:
        data = json.loads(request.body)
        showtime_id = data.get('showtime_id')
        seat_ids = data.get('seat_ids', [])

        if not seat_ids or len(seat_ids) > 10:
            return JsonResponse({'error': 'Select 1-10 seats'}, status=400)

        showtime = get_object_or_404(ShowTime, id=showtime_id, is_active=True)

        with transaction.atomic():
            # Lock the seat rows to prevent race conditions (Task 5)
            seats = Seat.objects.select_for_update().filter(
                id__in=seat_ids, screen=showtime.screen, is_active=True
            )

            if seats.count() != len(seat_ids):
                return JsonResponse({'error': 'Invalid seats selected'}, status=400)

            # Check if any seat is already held/confirmed by another user
            conflict = SeatReservation.objects.filter(
                showtime=showtime,
                seat__in=seats,
                status__in=['held', 'confirmed'],
                expires_at__gt=timezone.now()
            ).exclude(user=request.user).select_for_update()

            if conflict.exists():
                conflicting = list(conflict.values_list('seat__row', 'seat__number'))
                return JsonResponse({
                    'error': 'Some seats just got booked',
                    'conflicting': conflicting
                }, status=409)

            # Release user's previous holdings for this showtime
            SeatReservation.objects.filter(
                showtime=showtime, user=request.user, status='held'
            ).update(status='released')

            # Create new reservations
            timeout = getattr(settings, 'SEAT_RESERVATION_TIMEOUT', 120)
            expires_at = timezone.now() + timezone.timedelta(seconds=timeout)
            reservations = [
                SeatReservation(
                    user=request.user,
                    showtime=showtime,
                    seat=seat,
                    status='held',
                    expires_at=expires_at
                )
                for seat in seats
            ]
            SeatReservation.objects.bulk_create(reservations)
            logger.info(f"User {request.user.id} reserved {len(seat_ids)} seats for showtime {showtime_id}")

        total = sum(s.price for s in seats)
        return JsonResponse({
            'success': True,
            'expires_at': expires_at.isoformat(),
            'total': float(total),
            'timeout': timeout,
        })

    except Exception as e:
        logger.error(f"Seat reservation error: {e}")
        return JsonResponse({'error': 'Reservation failed. Please try again.'}, status=500)


@login_required
def booking_summary(request, showtime_id):
    showtime = get_object_or_404(ShowTime.objects.select_related('movie', 'screen', 'screen__theater'), id=showtime_id)

    reservations = SeatReservation.objects.filter(
        showtime=showtime, user=request.user, status='held',
        expires_at__gt=timezone.now()
    ).select_related('seat')

    if not reservations.exists():
        messages.error(request, 'Your seat reservation has expired. Please select seats again.')
        return redirect('bookings:seat_selection', showtime_id=showtime_id)

    seats = [r.seat for r in reservations]
    subtotal = sum(s.price for s in seats)
    convenience_fee = round(float(subtotal) * 0.02, 2)
    total = float(subtotal) + convenience_fee

    context = {
        'showtime': showtime,
        'reservations': reservations,
        'seats': seats,
        'subtotal': subtotal,
        'convenience_fee': convenience_fee,
        'total': total,
        'razorpay_key': settings.RAZORPAY_KEY_ID,
    }
    return render(request, 'bookings/booking_summary.html', context)


@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).select_related(
        'showtime', 'showtime__movie', 'showtime__screen', 'showtime__screen__theater'
    ).prefetch_related('seats').order_by('-created_at')
    return render(request, 'bookings/my_bookings.html', {'bookings': bookings})


@login_required
def booking_detail(request, booking_id):
    booking = get_object_or_404(
        Booking.objects.select_related(
            'showtime', 'showtime__movie', 'showtime__screen', 'showtime__screen__theater'
        ).prefetch_related('seats'),
        booking_id=booking_id, user=request.user
    )
    return render(request, 'bookings/booking_detail.html', {'booking': booking})
