from django.apps import AppConfig


class BookingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookings'

    def ready(self):
        # Register periodic tasks via Celery Beat
        try:
            from django_celery_beat.models import PeriodicTask, IntervalSchedule
            import json

            schedule, _ = IntervalSchedule.objects.get_or_create(
                every=1, period=IntervalSchedule.MINUTES
            )
            PeriodicTask.objects.get_or_create(
                name='Release Expired Seat Reservations',
                defaults={
                    'interval': schedule,
                    'task': 'bookings.tasks.release_expired_reservations',
                    'args': json.dumps([]),
                }
            )
            # Retry failed emails every 5 minutes
            schedule5, _ = IntervalSchedule.objects.get_or_create(
                every=5, period=IntervalSchedule.MINUTES
            )
            PeriodicTask.objects.get_or_create(
                name='Retry Failed Emails',
                defaults={
                    'interval': schedule5,
                    'task': 'bookings.tasks.retry_failed_emails',
                    'args': json.dumps([]),
                }
            )
        except Exception:
            pass  # DB not ready during migrations
