from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('select-seats/<int:showtime_id>/', views.seat_selection, name='seat_selection'),
    path('reserve/', views.reserve_seats, name='reserve_seats'),
    path('summary/<int:showtime_id>/', views.booking_summary, name='booking_summary'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('detail/<str:booking_id>/', views.booking_detail, name='booking_detail'),
]
