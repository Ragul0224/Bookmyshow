from django.db import models
from django.conf import settings
from django.utils import timezone
import uuid


class SeatReservation(models.Model):
    """Temporary seat lock — expires after SEAT_RESERVATION_TIMEOUT seconds."""
    STATUS_CHOICES = [
        ('held', 'Held'),
        ('confirmed', 'Confirmed'),
        ('expired', 'Expired'),
        ('released', 'Released'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reservations')
    showtime = models.ForeignKey('movies.ShowTime', on_delete=models.CASCADE, related_name='reservations')
    seat = models.ForeignKey('movies.Seat', on_delete=models.CASCADE, related_name='reservations')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='held')
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        unique_together = ['showtime', 'seat']  # Prevents double booking at DB level
        indexes = [
            models.Index(fields=['showtime', 'seat', 'status']),
            models.Index(fields=['status', 'expires_at']),
            models.Index(fields=['user', 'status']),
        ]

    def save(self, *args, **kwargs):
        if not self.expires_at:
            timeout = getattr(settings, 'SEAT_RESERVATION_TIMEOUT', 120)
            self.expires_at = timezone.now() + timezone.timedelta(seconds=timeout)
        super().save(*args, **kwargs)

    def is_expired(self):
        return timezone.now() > self.expires_at and self.status == 'held'

    def __str__(self):
        return f"{self.user} - {self.seat} ({self.status})"


class Booking(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    booking_id = models.CharField(max_length=20, unique=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings')
    showtime = models.ForeignKey('movies.ShowTime', on_delete=models.CASCADE, related_name='bookings')
    seats = models.ManyToManyField('movies.Seat', through='BookingSeat')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='pending')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    convenience_fee = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    payment_id = models.CharField(max_length=200, blank=True)
    idempotency_key = models.CharField(max_length=100, unique=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    email_sent = models.BooleanField(default=False)
    email_sent_at = models.DateTimeField(null=True, blank=True)
    email_retries = models.PositiveIntegerField(default=0)

    class Meta:
        indexes = [
            models.Index(fields=['booking_id']),
            models.Index(fields=['user', 'status']),
            models.Index(fields=['showtime', 'status']),
            models.Index(fields=['created_at']),
            models.Index(fields=['status', 'created_at']),
        ]

    def save(self, *args, **kwargs):
        if not self.booking_id:
            import random, string
            self.booking_id = 'BMS' + ''.join(random.choices(string.digits, k=10))
        if not self.idempotency_key:
            self.idempotency_key = str(uuid.uuid4())
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Booking {self.booking_id} - {self.user}"


class BookingSeat(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)
    seat = models.ForeignKey('movies.Seat', on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=8, decimal_places=2)

    class Meta:
        unique_together = ['booking', 'seat']


class EmailLog(models.Model):
    """Tracks email delivery for monitoring and retry."""
    STATUS_CHOICES = [('pending', 'Pending'), ('sent', 'Sent'), ('failed', 'Failed'), ('retrying', 'Retrying')]
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='email_logs')
    recipient = models.EmailField()
    subject = models.CharField(max_length=200)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='pending')
    attempts = models.PositiveIntegerField(default=0)
    last_attempt = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=['status', 'attempts']),
            models.Index(fields=['booking']),
        ]
