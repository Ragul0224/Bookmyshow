from celery import shared_task
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils import timezone
from django.conf import settings
import logging

logger = logging.getLogger('emails')

MAX_RETRIES = 3
RETRY_BACKOFF = 60  # seconds


@shared_task(bind=True, max_retries=MAX_RETRIES, default_retry_delay=RETRY_BACKOFF)
def send_booking_confirmation_email(self, booking_id):
    """
    Task 2: Async email with retry logic. Non-blocking - runs via Celery queue.
    """
    from bookings.models import Booking, EmailLog

    try:
        booking = Booking.objects.select_related(
            'user', 'showtime', 'showtime__movie',
            'showtime__screen', 'showtime__screen__theater', 'showtime__language'
        ).prefetch_related('seats').get(id=booking_id)

        # Get or create email log
        email_log, _ = EmailLog.objects.get_or_create(
            booking=booking,
            defaults={
                'recipient': booking.user.email,
                'subject': f'Booking Confirmed - {booking.booking_id}',
                'status': 'pending',
            }
        )
        email_log.attempts += 1
        email_log.last_attempt = timezone.now()
        email_log.status = 'retrying' if email_log.attempts > 1 else 'pending'
        email_log.save()

        # Render email using template engine (Task 2)
        seats = list(booking.seats.all())
        context = {
            'booking': booking,
            'seats': seats,
            'showtime': booking.showtime,
            'movie': booking.showtime.movie,
            'theater': booking.showtime.screen.theater,
            'user': booking.user,
        }

        text_content = render_to_string('emails/booking_confirmation.txt', context)
        html_content = render_to_string('emails/booking_confirmation.html', context)

        msg = EmailMultiAlternatives(
            subject=f'Booking Confirmed - {booking.booking_id} | BookMyShow',
            body=text_content,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[booking.user.email],
        )
        msg.attach_alternative(html_content, 'text/html')
        msg.send(fail_silently=False)

        # Mark success
        email_log.status = 'sent'
        email_log.sent_at = timezone.now()
        email_log.save()

        booking.email_sent = True
        booking.email_sent_at = timezone.now()
        booking.email_retries = email_log.attempts
        booking.save(update_fields=['email_sent', 'email_sent_at', 'email_retries'])

        logger.info(f"Email sent successfully for booking {booking.booking_id}")

    except Booking.DoesNotExist:
        logger.error(f"Booking {booking_id} not found for email")
    except Exception as exc:
        logger.error(f"Email failed for booking {booking_id}, attempt {self.request.retries + 1}: {exc}")
        try:
            from bookings.models import EmailLog
            booking_obj = Booking.objects.get(id=booking_id)
            EmailLog.objects.filter(booking=booking_obj).update(
                status='failed', error_message=str(exc)
            )
        except Exception:
            pass
        # Retry with exponential backoff (Task 2)
        raise self.retry(exc=exc, countdown=RETRY_BACKOFF * (self.request.retries + 1))


@shared_task
def release_expired_reservations():
    """
    Task 5: Background job to auto-release expired seat holds.
    Runs periodically via Celery Beat.
    """
    from bookings.models import SeatReservation
    from django.db.models import F

    now = timezone.now()
    expired = SeatReservation.objects.filter(status='held', expires_at__lt=now)
    count = expired.count()
    if count:
        expired.update(status='expired')
        logger.info(f"Released {count} expired seat reservations")
    return count


@shared_task
def retry_failed_emails():
    """Task 2: Retry failed email deliveries."""
    from bookings.models import EmailLog

    failed_logs = EmailLog.objects.filter(
        status='failed', attempts__lt=MAX_RETRIES
    ).select_related('booking')

    for log in failed_logs:
        send_booking_confirmation_email.delay(str(log.booking.id))
        logger.info(f"Queued retry for booking {log.booking.booking_id}")
