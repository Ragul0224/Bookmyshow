from django.contrib import admin
from .models import Booking, BookingSeat, SeatReservation, EmailLog


class BookingSeatInline(admin.TabularInline):
    model = BookingSeat
    extra = 0
    readonly_fields = ['seat', 'price']


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['booking_id', 'user', 'showtime', 'status', 'total_amount', 'email_sent', 'created_at']
    list_filter = ['status', 'email_sent', 'created_at']
    search_fields = ['booking_id', 'user__username', 'user__email']
    readonly_fields = ['id', 'booking_id', 'idempotency_key', 'created_at', 'confirmed_at']
    inlines = [BookingSeatInline]
    date_hierarchy = 'created_at'


@admin.register(SeatReservation)
class SeatReservationAdmin(admin.ModelAdmin):
    list_display = ['user', 'showtime', 'seat', 'status', 'expires_at']
    list_filter = ['status']
    readonly_fields = ['id', 'created_at', 'expires_at']


@admin.register(EmailLog)
class EmailLogAdmin(admin.ModelAdmin):
    list_display = ['booking', 'recipient', 'status', 'attempts', 'last_attempt', 'sent_at']
    list_filter = ['status']
    readonly_fields = ['created_at']
